"""
Brick: a single destructible (or indestructible) block.
"""

import pygame

NORMAL = "normal"
STRONG = "strong"
UNBREAKABLE = "unbreakable"

STRONG_HITS = 3

NORMAL_COLOR = (200, 90, 90)
UNBREAKABLE_COLOR = (130, 130, 140)
# Strong bricks get lighter as they take damage, indexed by hits_remaining.
STRONG_COLORS = {3: (70, 90, 200), 2: (110, 140, 230), 1: (160, 185, 245)}


class Brick:
    def __init__(self, x, y, width, height, kind=NORMAL):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.kind = kind
        self.hits_remaining = STRONG_HITS if kind == STRONG else 1

    @property
    def breakable(self):
        return self.kind != UNBREAKABLE

    @property
    def color(self):
        if self.kind == UNBREAKABLE:
            return UNBREAKABLE_COLOR
        if self.kind == STRONG:
            return STRONG_COLORS[max(1, min(self.hits_remaining, STRONG_HITS))]
        return NORMAL_COLOR

    def hit(self):
        """Register a hit. Returns True if the brick is now destroyed."""
        if not self.breakable:
            return False
        self.hits_remaining -= 1
        return self.hits_remaining <= 0

    def get_rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.width, self.height)
