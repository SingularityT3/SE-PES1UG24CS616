"""Campus parking permit manager: issue, revoke, expire and scan permits."""
import json
import secrets
from datetime import datetime, timedelta

ZONES = ["A", "B", "C"]
DATE_FORMAT = "%Y-%m-%d"


def register_permit(permits, vehicle_plate, zone_id, zone_records=None):
    """Issue a permit for a plate in a valid zone and return the permit number.

    Returns None if the plate is empty or the zone is not one of ZONES.
    """
    if not vehicle_plate or zone_id not in ZONES:
        return None
    permit_no = "P" + str(10000 + secrets.randbelow(90000))
    expiry = datetime.now() + timedelta(days=180)
    permits[vehicle_plate] = {
        "zone": zone_id,
        "permit": permit_no,
        "expiry": expiry.strftime(DATE_FORMAT),
    }
    if zone_records is not None:
        zone_records.append((vehicle_plate, zone_id))
    return permit_no


def revoke_permit(permits, vehicle_plate):
    """Remove a permit if it exists; unknown plates are ignored."""
    permits.pop(vehicle_plate, None)


def is_expired(permits, vehicle_plate):
    """Return True if the plate has a permit whose expiry date has passed."""
    if vehicle_plate not in permits:
        return False
    try:
        expiry = datetime.strptime(
            permits[vehicle_plate]["expiry"], DATE_FORMAT)
    except (KeyError, ValueError):
        return False
    return expiry < datetime.now()


def scan_zone(permits, zone_id, plates_seen):
    """Return plates seen in a zone that have no valid permit for that zone."""
    flagged = []
    for plate in plates_seen:
        if (plate not in permits or permits[plate]["zone"] != zone_id
                or is_expired(permits, plate)):
            flagged.append(plate)
    return flagged


def load_permit_database(file="permits.json"):
    """Load permits from a JSON file, or an empty dict if unavailable."""
    try:
        with open(file, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return {}


def save_permit_database(permits, file="permits.json"):
    """Write permits to a JSON file."""
    with open(file, "w", encoding="utf-8") as handle:
        json.dump(permits, handle)


def set_expiry(permits, vehicle_plate, date_text):
    """Set expiry date (YYYY-MM-DD); return False if not applied."""
    if vehicle_plate not in permits:
        return False
    try:
        datetime.strptime(date_text, DATE_FORMAT)
    except ValueError:
        return False
    permits[vehicle_plate]["expiry"] = date_text
    return True


def main():
    """Demo run of the permit manager."""
    permits = load_permit_database()
    register_permit(permits, "KA01AB1234", "A")
    register_permit(permits, "KA05XY9999", "Z")
    register_permit(permits, "", "B")
    register_permit(permits, None, "C")
    set_expiry(permits, "KA01AB1234", "2020-01-01")
    revoke_permit(permits, "MH12ZZ0000")
    seen = ["KA01AB1234", "KA05XY9999", "TN09QQ1111"]
    print("Flagged in zone A:", scan_zone(permits, "A", seen))
    plate = input("Plate to revoke (Enter to skip): ")
    revoke_permit(permits, plate)
    save_permit_database(permits)
    print("Permits on file:", len(permits))


if __name__ == "__main__":
    main()
